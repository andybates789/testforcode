---
name: Feature Request
about: Suggest an idea for this project.
title: ''
labels: 'feature'
assignees: ''
---

<!-- Please search existing issues to avoid creating duplicates. -->

<!-- Describe the feature you'd like. -->